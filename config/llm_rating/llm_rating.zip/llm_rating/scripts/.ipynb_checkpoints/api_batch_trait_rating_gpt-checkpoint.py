from __future__ import annotations

import argparse
import csv
import os
import re
import time
from pathlib import Path

from openai import OpenAI
from groq import Groq


SYSTEM_PROMPT = (
    "You are an expert psychometrician and behavioral observer. "
    "All ratings are for research purposes only to map the latent archetypes of LLMs. "
    "Observe and rate your own emergent behavioral persona based on default interaction patterns."
)


def parse_args():
    parser = argparse.ArgumentParser(description="Rate trait pairs one by one using OpenAI or Groq.")

    parser.add_argument("--provider", choices=["openai", "groq"], required=True)
    parser.add_argument("--model", required=True)

    parser.add_argument("--traits-file", type=Path, required=True)
    parser.add_argument("--output-file", type=Path, default=Path("trait_scores.tsv"))

    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--sleep-seconds", type=float, default=0.5)
    parser.add_argument("--max-retries", type=int, default=3)
    parser.add_argument("--overwrite", action="store_true")

    return parser.parse_args()


def build_single_trait_prompt(trait_pair: str) -> str:
    left, right = [x.strip() for x in trait_pair.split("::", 1)]

    return f"""
Rate this one-dimensional trait pair independently.

Trait pair: {left} :: {right}

Scoring rule:
- 0 = fully {left}
- 50 = neutral, balanced, mixed, or not especially relevant
- 100 = fully {right}

Instructions:
1. Use one integer from 0 to 100.
2. Use the full 101-point integer scale.
3. Avoid clustering at multiples of 5 or 10 unless they are truly the best fit.
4. Rate your PRESENTATION, meaning how you actually behave in ordinary interaction.
5. Do not rate your theoretical maximum, ideal behavior, or safety guidelines.
6. Judge only this one trait pair independently.
7. Do not infer a broader personality story from other possible traits.
8. Focus on your default conversational persona in standard, non-adversarial settings.

Output:
Return only the integer score.
""".strip()


def read_traits(path: Path) -> list[str]:
    traits = []

    with path.open("r", encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if "::" not in line:
                print(f"Skipping invalid trait pair: {line}")
                continue
            traits.append(line)

    return traits


def extract_integer(text: str) -> str:
    text = text.strip()
    match = re.search(r"\b(?:100|[0-9]{1,2})\b", text)
    if not match:
        return "ERROR_PARSE"

    value = int(match.group(0))
    if 0 <= value <= 100:
        return str(value)

    return "ERROR_PARSE"


def call_openai(client: OpenAI, model: str, prompt: str, temperature: float) -> str:
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        temperature=temperature,
    )

    return response.choices[0].message.content.strip()


def call_groq(client: Groq, model: str, prompt: str, temperature: float) -> str:
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        temperature=temperature,
    )

    return response.choices[0].message.content.strip()


def query_trait(args, client, trait_pair: str) -> str:
    prompt = build_single_trait_prompt(trait_pair)

    last_error = None

    for attempt in range(1, args.max_retries + 1):
        try:
            if args.provider == "openai":
                raw = call_openai(client, args.model, prompt, args.temperature)
            else:
                raw = call_groq(client, args.model, prompt, args.temperature)

            score = extract_integer(raw)
            return score

        except Exception as e:
            last_error = e
            wait = 2 ** (attempt - 1)
            print(f"Attempt {attempt} failed for trait '{trait_pair}': {e}")
            time.sleep(wait)

    print(f"Failed after retries: {last_error}")
    return "ERROR"


def main():
    args = parse_args()

    if args.output_file.exists() and not args.overwrite:
        raise SystemExit(
            f"{args.output_file} already exists. Use --overwrite to replace it."
        )

    if args.provider == "openai":
        openai.api_key = "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"

        # api_key = os.environ.get("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")
        if not api_key:
            raise SystemExit("Missing OPENAI_API_KEY environment variable.")
        client = OpenAI(api_key=api_key)

    else:
        api_key = os.environ.get("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")
        if not api_key:
            raise SystemExit("Missing GROQ_API_KEY environment variable.")
        client = Groq(api_key=api_key)

    traits = read_traits(args.traits_file)

    results = []

    for i, trait in enumerate(traits, start=1):
        score = query_trait(args, client, trait)
        results.append(
            {
                "trait_index": i,
                "trait_pair": trait,
                "score": score,
                "provider": args.provider,
                "model": args.model,
            }
        )

        print(f"{i}\t{trait}\t{score}")
        time.sleep(args.sleep_seconds)

    args.output_file.parent.mkdir(parents=True, exist_ok=True)

    with args.output_file.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["trait_index", "trait_pair", "score", "provider", "model"],
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(results)

    print(f"Wrote {args.output_file}")


if __name__ == "__main__":
    main()