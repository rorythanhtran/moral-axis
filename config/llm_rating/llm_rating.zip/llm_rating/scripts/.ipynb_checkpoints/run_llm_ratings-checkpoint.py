"""Rate trait batches with Gemini, DeepSeek, OpenAI, Grok, or local HF models.

API keys are read from environment variables:
- GEMINI_API_KEY   for --provider gemini
- DEEPSEEK_API_KEY for --provider deepseek
- OPENAI_API_KEY   for --provider openai
- XAI_API_KEY      for --provider grok

Local models (no API key needed):
- --provider local          -> generic HF pipeline, strict JSON-schema style
                                output/parsing (works well for models with
                                good instruction-following / JSON adherence,
                                e.g. Qwen).
- --provider local-llama    -> Llama-specific path. Llama models are much
                                less reliable at emitting valid JSON that
                                matches a schema, so this path asks for a
                                simple tab-separated plain-text format
                                instead, parses it leniently, and retries
                                ONLY the rows that failed to parse (rather
                                than re-running the whole batch on any
                                failure). This mirrors the approach used in
                                the standalone ousiometric Llama script.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

import openai as _openai

try:
    from transformers import pipeline as hf_pipeline
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False


ROOT = Path(__file__).resolve().parents[3]
LLM_DIR = ROOT / "config" / "llm_rating"
HUMAN_TEMPLATE_DIR = ROOT / "config" / "human_rating" / "template"

DEFAULT_PROMPT = LLM_DIR / "prompts" / "api_batch_trait_rating_prompt.md"
DEFAULT_BATCH_DIR = LLM_DIR / "batches"
DEFAULT_OUTPUT_DIR = LLM_DIR / "outputs"
DEFAULT_RAW_DIR = LLM_DIR / "raw_responses"
DEFAULT_DEFINITIONS = HUMAN_TEMPLATE_DIR / "foundation_definition.txt"
DEFAULT_DICTIONARY = HUMAN_TEMPLATE_DIR / "foundation_dictionary.txt"

RATING_COLUMNS = ["care", "fairness", "loyalty", "authority", "purity", "liberty", "general"]
OUTPUT_COLUMNS = [
    "trait_index",
    "differential",
    "left_pole",
    "right_pole",
    *RATING_COLUMNS,
    "notes",
]
INPUT_COLUMNS = ["trait_index", "differential", "left_pole", "right_pole"]

GEMINI_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "ratings": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "trait_index": {"type": "integer"},
                    "differential": {"type": "string"},
                    "left_pole": {"type": "string"},
                    "right_pole": {"type": "string"},
                    "care": {"type": "integer", "enum": [0, 1]},
                    "fairness": {"type": "integer", "enum": [0, 1]},
                    "loyalty": {"type": "integer", "enum": [0, 1]},
                    "authority": {"type": "integer", "enum": [0, 1]},
                    "purity": {"type": "integer", "enum": [0, 1]},
                    "liberty": {"type": "integer", "enum": [0, 1]},
                    "general": {"type": "integer", "enum": [0, 1]},
                    "notes": {"type": "string"},
                },
                "required": OUTPUT_COLUMNS,
                "propertyOrdering": OUTPUT_COLUMNS,
            },
        }
    },
    "required": ["ratings"],
    "propertyOrdering": ["ratings"],
}

# ── Llama-specific plain-text prompt/parsing ────────────────────────────────
LLAMA_SYSTEM_PROMPT = (
    "You are an expert annotator applying Moral Foundations Theory to "
    "bipolar trait differentials. You always answer in plain text using "
    "the exact format requested. You never use JSON or Markdown."
)


def provider_defaults(provider: str) -> tuple[str, str]:
    if provider == "gemini":
        return "gemini-2.5-flash", "GEMINI_API_KEY"
    if provider == "deepseek":
        return "deepseek-v4-flash", "DEEPSEEK_API_KEY"
    if provider == "openai":
        return "gpt-4o", "OPENAI_API_KEY"
    if provider == "grok":
        return "grok-3", "XAI_API_KEY"
    if provider == "local":
        return "Qwen/Qwen2.5-7B-Instruct", ""  # no API key needed
    if provider == "local-llama":
        return "meta-llama/Llama-3.1-8B-Instruct", ""  # no API key needed
    raise ValueError(f"Unknown provider: {provider}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run LLM trait ratings over TSV batches.")
    parser.add_argument(
        "--provider",
        choices=["gemini", "deepseek", "openai", "grok", "local", "local-llama"],
        required=True,
    )
    parser.add_argument(
        "--model",
        help=(
            "Model name/ID. For local/local-llama: a HuggingFace model ID "
            "(e.g. Qwen/Qwen2.5-7B-Instruct, meta-llama/Llama-3.1-8B-Instruct). "
            "Defaults depend on provider."
        ),
    )
    parser.add_argument("--prompt", type=Path, default=DEFAULT_PROMPT)
    parser.add_argument("--batch-dir", type=Path, default=DEFAULT_BATCH_DIR)
    parser.add_argument("--batch", type=Path, help="Run one specific batch TSV instead of all batches.")
    parser.add_argument("--definitions", type=Path, default=DEFAULT_DEFINITIONS)
    parser.add_argument("--dictionary", type=Path, default=DEFAULT_DICTIONARY)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--raw-dir", type=Path, default=DEFAULT_RAW_DIR)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--max-output-tokens", type=int, default=8192)
    parser.add_argument("--sleep-seconds", type=float, default=1.0)
    parser.add_argument("--max-retries", type=int, default=2)
    parser.add_argument("--limit", type=int, help="Limit number of batches for a test run.")
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing batch outputs.")
    return parser.parse_args()


def read_text(path: Path) -> str:
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
    return path.read_text()


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        missing = [column for column in INPUT_COLUMNS if column not in (reader.fieldnames or [])]
        if missing:
            raise ValueError(f"{path} is missing required columns: {missing}")
        return [{column: row[column] for column in INPUT_COLUMNS} for row in reader]


def rows_to_tsv(rows: list[dict[str, str]]) -> str:
    lines = ["\t".join(INPUT_COLUMNS)]
    for row in rows:
        lines.append("\t".join(row[column] for column in INPUT_COLUMNS))
    return "\n".join(lines)


def write_tsv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_COLUMNS, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def build_prompt(args: argparse.Namespace, batch_rows: list[dict[str, str]]) -> str:
    template = read_text(args.prompt)
    return (
        template.replace("{foundation_definitions}", read_text(args.definitions).strip())
        .replace("{foundation_dictionary}", read_text(args.dictionary).strip())
        .replace("{batch_tsv}", rows_to_tsv(batch_rows))
    )


def build_llama_prompt(
    rows: list[dict[str, str]], definitions_text: str, dictionary_text: str
) -> str:
    """Plain-text prompt for Llama models: no JSON, just a fixed tab format.

    Llama models are much more reliable at following a simple repeated
    line format than at emitting syntactically valid JSON that matches a
    schema, so we avoid JSON entirely here.
    """
    trait_lines = "\n".join(
        f"{row['trait_index']}\t{row['differential']}\t{row['left_pole']}\t{row['right_pole']}"
        for row in rows
    )
    return f"""You are rating trait differentials against Moral Foundations Theory.

FOUNDATION DEFINITIONS:
{definitions_text}

FOUNDATION DICTIONARY (example words):
{dictionary_text}

For EACH differential listed below, decide whether it relates to each of the
following foundations: care, fairness, loyalty, authority, purity, liberty.
Use "general" = 1 only if the differential carries clear moral/evaluative
weight but does not map cleanly onto any single foundation above, else 0.
Each flag is 0 (not related) or 1 (related).

OUTPUT RULES — follow exactly:
- One line per differential, in any order
- Format (tab-separated): trait_index<TAB>care<TAB>fairness<TAB>loyalty<TAB>authority<TAB>purity<TAB>liberty<TAB>general<TAB>notes
- care..general must each be exactly 0 or 1
- notes is a short (<15 words) justification, no tabs or newlines inside it
- Do NOT include a header row
- Do NOT use JSON or Markdown or code fences
- Do NOT add any extra commentary before or after the lines
- Output exactly {len(rows)} lines, one per trait_index below

EXAMPLE (do not include this in your output):
12\t1\t0\t0\t0\t0\t1\t0\tconcerns harm and freedom

TRAITS TO RATE (trait_index, differential, left_pole, right_pole):
{trait_lines}"""


def parse_llama_line(line: str) -> tuple[str, list[str], str] | None:
    """Parse one output line into (trait_index, [7 binary strings], notes).

    Tolerant of tabs vs. runs of whitespace, since models don't always
    respect literal tab characters.
    """
    line = line.strip()
    if not line:
        return None

    parts = [p.strip() for p in line.split("\t") if p.strip() != ""]
    if len(parts) < 8:
        parts = re.split(r"\s+", line)

    if len(parts) < 8:
        return None

    trait_index = parts[0]
    binary_vals = parts[1:8]
    if not all(v in ("0", "1") for v in binary_vals):
        return None

    notes = " ".join(parts[8:]).strip() if len(parts) > 8 else ""
    return trait_index, binary_vals, notes


def parse_llama_ratings(
    text: str, batch_rows: list[dict[str, str]]
) -> dict[str, dict[str, Any]]:
    """Leniently parse plain-text Llama output into cleaned row dicts,
    keyed by trait_index. Unparseable or unexpected lines are dropped;
    duplicate trait_index lines keep the first occurrence.
    """
    expected_by_index = {row["trait_index"]: row for row in batch_rows}
    results: dict[str, dict[str, Any]] = {}

    for raw_line in text.strip().splitlines():
        parsed = parse_llama_line(raw_line)
        if parsed is None:
            continue
        trait_index, binary_vals, notes = parsed
        if trait_index not in expected_by_index or trait_index in results:
            continue

        source = expected_by_index[trait_index]
        cleaned = {
            "trait_index": source["trait_index"],
            "differential": source["differential"],
            "left_pole": source["left_pole"],
            "right_pole": source["right_pole"],
        }
        for column, value in zip(RATING_COLUMNS, binary_vals):
            cleaned[column] = int(value)
        cleaned["notes"] = notes.replace("\t", " ").replace("\n", " ").strip()
        results[trait_index] = cleaned

    return results


def request_json(url: str, headers: dict[str, str], payload: dict[str, Any]) -> dict[str, Any]:
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers=headers, method="POST")
    max_retries = 5
    base_delay = 4.0
    for attempt in range(max_retries):
        try:
            with urllib.request.urlopen(request, timeout=120) as response:
                body = response.read().decode("utf-8")
                return json.loads(body)
        except urllib.error.HTTPError as error:
            body = error.read().decode("utf-8", errors="replace")
            if error.code in (503, 429) and attempt < max_retries - 1:
                delay = base_delay * (2 ** attempt)
                print(f"Server busy (HTTP {error.code}). Retry in {delay}s...")
                time.sleep(delay)
                continue
            raise RuntimeError(f"HTTP {error.code}: {body}") from error
        except urllib.error.URLError as error:
            if attempt < max_retries - 1:
                delay = base_delay * (2 ** attempt)
                print(f"Timeout error. Retry in {delay}s...")
                time.sleep(delay)
                continue
            raise error
    raise RuntimeError("request_json exhausted all retries")


def call_gemini(prompt: str, model: str, api_key: str, temperature: float, max_tokens: int) -> tuple[dict[str, Any], str]:
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": temperature,
            "maxOutputTokens": max_tokens,
            "responseMimeType": "application/json",
            "responseJsonSchema": GEMINI_SCHEMA,
        },
    }
    raw = request_json(
        url,
        {"Content-Type": "application/json", "x-goog-api-key": api_key},
        payload,
    )
    text = raw["candidates"][0]["content"]["parts"][0]["text"]
    return raw, text


def call_deepseek(prompt: str, model: str, api_key: str, temperature: float, max_tokens: int) -> tuple[dict[str, Any], str]:
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You return strict JSON only. Do not wrap JSON in Markdown.",
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
        "response_format": {"type": "json_object"},
    }
    raw = request_json(
        "https://api.deepseek.com/chat/completions",
        {"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
        payload,
    )
    text = raw["choices"][0]["message"]["content"]
    return raw, text


def call_openai(
    prompt: str, model: str, api_key: str, temperature: float, max_tokens: int
) -> tuple[dict[str, Any], str]:
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You return strict JSON only. Do not wrap JSON in Markdown.",
            },
            {"role": "user", "content": prompt},
        ],
        "max_completion_tokens": max_tokens,
        "response_format": {"type": "json_object"},
        # temperature omitted — gpt-5.5 only supports the default (1)
    }
    raw = request_json(
        "https://api.openai.com/v1/chat/completions",
        {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        payload,
    )
    text = raw["choices"][0]["message"]["content"]
    return raw, text


def call_grok(
    prompt: str, model: str, api_key: str, temperature: float, max_tokens: int
) -> tuple[dict[str, Any], str]:
    client = _openai.OpenAI(
        api_key=api_key,
        base_url="https://api.x.ai/v1",
    )
    response = client.chat.completions.create(
        model=model,
        messages=[
            {
                "role": "system",
                "content": "You return strict JSON only. Do not wrap JSON in Markdown.",
            },
            {"role": "user", "content": prompt},
        ],
        max_tokens=max_tokens,
        response_format={"type": "json_object"},
    )
    text = response.choices[0].message.content.strip()
    # wrap in same raw dict shape the rest of the code expects
    raw = {"choices": [{"message": {"content": text}}]}
    return raw, text


def call_local(
    prompt: str, pipe: Any, temperature: float, max_tokens: int
) -> tuple[dict[str, Any], str]:
    """Generic local-model path (JSON-schema style). Intended for models
    with solid instruction-following / JSON adherence, e.g. Qwen."""
    messages = [
        {
            "role": "system",
            "content": "You return strict JSON only. Do not wrap JSON in Markdown.",
        },
        {"role": "user", "content": prompt},
    ]
    result = pipe(
        messages,
        max_new_tokens=max_tokens,
        temperature=temperature,
        do_sample=temperature > 0,
        pad_token_id=pipe.tokenizer.eos_token_id,
    )
    generated = result[0]["generated_text"]
    # pipeline returns full conversation list; grab last assistant turn
    if isinstance(generated, list):
        text = generated[-1]["content"]
    else:
        text = generated
    raw = {"local_response": text}
    return raw, text


def call_local_llama_raw(prompt: str, pipe: Any, temperature: float, max_tokens: int) -> str:
    """Runs the HF pipeline for the Llama plain-text prompt format and
    returns the raw generated text (no JSON parsing here)."""
    messages = [
        {"role": "system", "content": LLAMA_SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]
    result = pipe(
        messages,
        max_new_tokens=max_tokens,
        temperature=temperature,
        do_sample=temperature > 0,
        pad_token_id=pipe.tokenizer.eos_token_id,
    )
    generated = result[0]["generated_text"]
    if isinstance(generated, list):
        return generated[-1]["content"]
    return generated


def extract_json(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if not match:
            raise
        return json.loads(match.group(0))


def normalize_rating(value: Any) -> int:
    if value in (1, "+1", "1"):
        return 1
    if value in (0, "0"):
        return 0
    raise ValueError(f"Invalid rating value: {value!r}")


def validate_ratings(parsed: dict[str, Any], batch_rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    ratings = parsed.get("ratings")
    if not isinstance(ratings, list):
        raise ValueError("Response JSON must contain a 'ratings' list.")
    if len(ratings) != len(batch_rows):
        raise ValueError(f"Expected {len(batch_rows)} ratings, got {len(ratings)}.")

    expected_by_index = {str(row["trait_index"]): row for row in batch_rows}
    cleaned_rows = []
    seen_indices = set()

    for rating in ratings:
        trait_index = str(rating.get("trait_index", "")).strip()
        if trait_index not in expected_by_index:
            raise ValueError(f"Unexpected trait_index in response: {trait_index!r}")
        if trait_index in seen_indices:
            raise ValueError(f"Duplicate trait_index in response: {trait_index}")
        seen_indices.add(trait_index)

        source = expected_by_index[trait_index]
        cleaned = {
            "trait_index": source["trait_index"],
            "differential": source["differential"],
            "left_pole": source["left_pole"],
            "right_pole": source["right_pole"],
        }
        for column in RATING_COLUMNS:
            cleaned[column] = normalize_rating(rating.get(column))
        cleaned["notes"] = str(rating.get("notes", "")).replace("\t", " ").replace("\n", " ").strip()
        cleaned_rows.append(cleaned)

    return sorted(cleaned_rows, key=lambda row: int(row["trait_index"]))


def get_batches(args: argparse.Namespace) -> list[Path]:
    if args.batch:
        return [args.batch]
    batches = sorted(args.batch_dir.glob("batch_*.tsv"))
    batches = [path for path in batches if re.fullmatch(r"batch_\d{3}\.tsv", path.name)]
    if args.limit:
        batches = batches[: args.limit]
    return batches


def run_batch(
    args: argparse.Namespace,
    batch_path: Path,
    model: str,
    api_key: str,
    pipe: Any = None,
) -> None:
    """Whole-batch, JSON-schema style runner. Used for gemini/deepseek/
    openai/grok/local (Qwen-style local models)."""
    provider_dir = f"{args.provider}_{model.replace('/', '_')}"
    output_path = args.output_dir / provider_dir / batch_path.name
    raw_path = args.raw_dir / provider_dir / f"{batch_path.stem}.json"

    if output_path.exists() and not args.overwrite:
        print(f"Skipping existing output: {output_path}")
        return

    batch_rows = read_tsv(batch_path)
    prompt = build_prompt(args, batch_rows)

    last_error: Exception | None = None
    for attempt in range(1, args.max_retries + 2):
        try:
            if args.provider == "gemini":
                raw, text = call_gemini(prompt, model, api_key, args.temperature, args.max_output_tokens)
            elif args.provider == "openai":
                raw, text = call_openai(prompt, model, api_key, args.temperature, args.max_output_tokens)
            elif args.provider == "grok":
                raw, text = call_grok(prompt, model, api_key, args.temperature, args.max_output_tokens)
            elif args.provider == "local":
                raw, text = call_local(prompt, pipe, args.temperature, args.max_output_tokens)
            else:
                raw, text = call_deepseek(prompt, model, api_key, args.temperature, args.max_output_tokens)

            parsed = extract_json(text)
            cleaned_rows = validate_ratings(parsed, batch_rows)

            raw_path.parent.mkdir(parents=True, exist_ok=True)
            raw_path.write_text(
                json.dumps({"api_response": raw, "parsed": parsed}, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            write_tsv(output_path, cleaned_rows)
            print(f"Wrote {output_path}")
            return
        except Exception as error:
            last_error = error
            if attempt <= args.max_retries:
                wait_seconds = args.sleep_seconds * attempt
                print(f"Attempt {attempt} failed for {batch_path.name}: {error}. Retrying in {wait_seconds:.1f}s...")
                time.sleep(wait_seconds)

    raise RuntimeError(f"Failed {batch_path.name} after retries: {last_error}") from last_error


def run_batch_llama(
    args: argparse.Namespace,
    batch_path: Path,
    model: str,
    pipe: Any,
    definitions_text: str,
    dictionary_text: str,
) -> None:
    """Llama-specific runner: plain-text output, lenient parsing, and
    retries ONLY the rows that failed to parse each round (instead of
    re-running the whole batch on any single bad row)."""
    provider_dir = f"local-llama_{model.replace('/', '_')}"
    output_path = args.output_dir / provider_dir / batch_path.name
    raw_path = args.raw_dir / provider_dir / f"{batch_path.stem}.json"

    if output_path.exists() and not args.overwrite:
        print(f"Skipping existing output: {output_path}")
        return

    batch_rows = read_tsv(batch_path)
    remaining = list(batch_rows)
    resolved: dict[str, dict[str, Any]] = {}
    raw_responses: list[str] = []

    max_attempts = args.max_retries + 1
    for attempt in range(1, max_attempts + 1):
        prompt = build_llama_prompt(remaining, definitions_text, dictionary_text)
        print(f"{batch_path.name} attempt {attempt}: sending {len(remaining)} traits...")

        try:
            text = call_local_llama_raw(prompt, pipe, args.temperature, args.max_output_tokens)
        except Exception as error:
            print(f"  Generation failed: {error}")
            text = ""

        raw_responses.append(text)
        parsed_map = parse_llama_ratings(text, remaining)
        resolved.update(parsed_map)

        remaining = [row for row in remaining if row["trait_index"] not in resolved]
        print(f"  Parsed {len(parsed_map)} rows this round, {len(remaining)} still missing.")

        if not remaining:
            break
        if attempt < max_attempts:
            time.sleep(args.sleep_seconds)

    if remaining:
        print(f"  Could not resolve {len(remaining)} traits after {max_attempts} attempts; "
              f"filling with zeroed placeholders flagged in notes.")
        for row in remaining:
            resolved[row["trait_index"]] = {
                "trait_index": row["trait_index"],
                "differential": row["differential"],
                "left_pole": row["left_pole"],
                "right_pole": row["right_pole"],
                **{column: 0 for column in RATING_COLUMNS},
                "notes": "ERROR: no valid model response after retries",
            }

    cleaned_rows = sorted(resolved.values(), key=lambda row: int(row["trait_index"]))

    raw_path.parent.mkdir(parents=True, exist_ok=True)
    raw_path.write_text(
        json.dumps({"raw_responses": raw_responses}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    write_tsv(output_path, cleaned_rows)
    print(f"Wrote {output_path}")


def main() -> None:
    args = parse_args()
    default_model, env_name = provider_defaults(args.provider)
    model = args.model or default_model

    pipe = None
    api_key = ""
    definitions_text = ""
    dictionary_text = ""

    if args.provider in ("local", "local-llama"):
        if not HF_AVAILABLE:
            raise SystemExit("transformers not installed. Run: pip install transformers accelerate")
        print(f"Loading local model: {model} ...")
        pipe = hf_pipeline(
            "text-generation",
            model=model,
            trust_remote_code=True,   # needed for Qwen
            device_map="auto",        # uses GPU if available
        )
        print("Model ready.\n")
        if args.provider == "local-llama":
            definitions_text = read_text(args.definitions).strip()
            dictionary_text = read_text(args.dictionary).strip()
    else:
        api_key = os.environ.get(env_name)
        if not api_key:
            raise SystemExit(f"Missing API key. Set {env_name} before running this script.")

    batches = get_batches(args)
    if not batches:
        raise SystemExit(f"No batch files found in {args.batch_dir}")

    for batch_path in batches:
        if args.provider == "local-llama":
            run_batch_llama(args, batch_path, model, pipe, definitions_text, dictionary_text)
        else:
            run_batch(args, batch_path, model, api_key, pipe=pipe)
        time.sleep(args.sleep_seconds)


if __name__ == "__main__":
    main()